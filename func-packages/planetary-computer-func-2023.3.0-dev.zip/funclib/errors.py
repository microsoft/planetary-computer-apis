class BBoxTooLargeError(Exception):
    pass


class InvalidInputError(Exception):
    pass
